

GLOBAL CONVENTIONS
------------------
A. Indexing
- Observation indices are 0-based.
- Feature indices are 0-based.

B. CART depth
- Root depth is 0.
- max_depth=2 permits splits at depths 0 and 1; depth-2 nodes are leaves.
- max_depth=3 permits splits at depths 0, 1, and 2; depth-3 nodes are leaves.

C. CART rules shared by Questions 1, 2, and 3
- Binary labels are 0 and 1.
- min_leaf = 3.
- Candidate thresholds are midpoints of consecutive DISTINCT FINITE values present at that node.
- For every (feature, threshold), BOTH missing-left and missing-right candidates are considered,
  even when the feature has no missing value at that node. If the partitions are identical,
  missing-left wins the final tie.
- A split is illegal if either child has fewer than 3 observations.
- Do not split a CART node if it is pure, is already at max_depth, or no legal split has strictly
  positive impurity decrease.
- Leaf prediction is majority class; a 0/1 tie predicts class 0.
- Split ordering: larger impurity decrease, smaller feature index, smaller threshold,
  missing-left before missing-right.
- Compare gains in float64 without rounding them first.

D. Question 2
- "Another depth-2 tree" obeys the same legal-split/min_leaf rules but need not choose greedy splits.
- You may choose the number of binary features in the construction.
- Duplicate observations are allowed and count separately toward n and min_leaf.

E. Question 3
- Use the SAME X_tree and y_tree supplied for Question 1.
- Before and after adding (x*, y*), use max_depth=2 and min_leaf=3.
- "Training accuracy decreases" means:
  accuracy(new tree on augmented n+1 training set) <
  accuracy(original tree on original n training set).
- x* must be a finite real vector with the same dimension as X_tree; y* is 0 or 1.

F. Question 4
- qda_pair is the ordered pair (a,b) for delta_a(x)=delta_b(x).
- All covariance matrices are symmetric positive definite.
- Natural logarithms are used.
- Report enough digits to demonstrate the requested 1e-10 boundary residual.

G. Binary metric conventions 
- Class 1 is positive.
- Accuracy = (TP+TN)/(TP+TN+FP+FN).
- Precision = TP/(TP+FP); define Precision=0 if TP+FP=0.
- Recall = TP/(TP+FN); define Recall=0 if TP+FN=0.
- F1 = 2*Precision*Recall/(Precision+Recall); define F1=0 if its denominator is zero.
- Balanced Accuracy = 0.5*(TPR+TNR). Both classes must be present in any construction.
- MCC is the standard binary Matthews correlation coefficient; if its denominator is zero,
  define MCC=0 for this assignment.

H. Scores, thresholds, ROC, and AP
- A threshold t predicts class 1 iff score >= t.
- Tied scores are processed as a single block; they may not be split at one threshold.
- ROC-AUC tie convention:
  P(s_positive > s_negative) + 0.5*P(s_positive = s_negative).
- Average Precision is the step-wise area:
  AP = sum_k (Recall_k - Recall_{k-1}) * Precision_k,
  where k runs over DISTINCT score levels in descending order after adding all examples tied at
  that level simultaneously. This is NOT trapezoidal PR-AUC.

I. 
- The supplied dataset-size bound is n <= 8.
- The labelled dataset must contain at least one positive and one negative example.
- Scores may be any real values in [0,1], including ties.
- Optimize over every valid construction with 2 <= n <= 8.
- An exhaustive certificate may enumerate equivalent score order/tie/threshold patterns instead
  of arbitrary floating values, provided the equivalence argument is clearly justified.



K. Question 9 diagnostic contract
- For buggy_code.py only: X is finite (no NaN/Inf), labels are binary, required metric inputs
  contain both classes, and covariance matrices are symmetric positive definite.
- buggy_code.py contains EXACTLY SIX conceptual bugs under that contract.
- Lack of NaN handling in buggy_code.py is NOT one of the six bugs.
- best_cart_split returns the best legal candidate for its caller-supplied min_leaf and leaves
  any nonpositive-gain stopping decision to its caller; neither point is one of the six bugs.
- Style/performance choices are not bugs unless they change the mathematically required output.

ASSIGNMENT_DATA.NPZ KEYS
------------------------
X_tree                          shape (15,2), common Q1/Q3 data
y_tree                          shape (15,)
tree_given_predictions          shape (15,), Q1 prediction vector to reconstruct
cart_reconstruction_max_depth  scalar 3
cart_attack_max_depth          scalar 2
cart_min_leaf                  scalar 3
qda_mus                        shape (3,2)
qda_covs                       shape (3,2,2)
qda_priors                     shape (3,)
qda_pair                       shape (2,), ordered Q4 pair
q7_max_n                       scalar 8
q8_train_prevalence            scalar 0.50
q8_deploy_prevalence           scalar 0.03
q8_cost_fp                     scalar 1.0
q8_cost_fn                     scalar 13.0

STARTER API
-----------
The public function names/signatures in starter.py are the interfaces used by the common hidden
test suite. Students may add helpers, but should not rename/remove those functions.

No hidden test data is included in the student distribution.
