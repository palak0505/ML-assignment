"""Question 9 diagnostic program.

Contract for THIS FILE ONLY:
- X is a finite real 2-D array (no NaN/Inf).
- y contains binary labels 0/1.
- covariance matrices are symmetric positive definite.
- ROC-AUC inputs contain both classes.

Exactly six conceptual errors are present.
"""
import numpy as np

def _gini(y):
    if len(y) == 0:
        return 0.0
    counts = np.bincount(np.asarray(y, dtype=int), minlength=2)
    p = counts / counts.sum()
    return 1.0 - np.sum(p * p)

def best_cart_split(X, y, min_leaf=1):
    """Return best legal candidate; caller supplies min_leaf and handles stopping."""
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=int)
    parent = _gini(y)
    best = None
    for j in range(X.shape[1]):
        values = np.unique(X[:, j])
        if len(values) < 2:
            continue
        thresholds = values[:-1]
        for t in thresholds:
            left = X[:, j] <= t
            right = ~left
            if left.sum() < min_leaf or right.sum() < min_leaf:
                continue
            gl = _gini(y[left])
            gr = _gini(y[right])
            child_impurity = 0.5 * gl + 0.5 * gr
            gain = parent - child_impurity
            candidate = (gain, -j, -float(t), j, float(t))
            if best is None or candidate > best:
                best = candidate
    if best is None:
        return None
    return {"feature": best[3], "threshold": best[4], "gain": best[0]}

def qda_scores(X, mus, covs, priors):
    X = np.atleast_2d(np.asarray(X, dtype=float))
    mus = np.asarray(mus, dtype=float)
    covs = np.asarray(covs, dtype=float)
    priors = np.asarray(priors, dtype=float)
    out = np.empty((len(X), len(mus)), dtype=float)
    for k in range(len(mus)):
        sign, logdet = np.linalg.slogdet(covs[k])
        if sign <= 0:
            raise ValueError("covariance must be positive definite")
        for i, x in enumerate(X):
            diff = x - mus[k]
            quad = diff @ np.linalg.solve(covs[k], diff)
            out[i, k] = -logdet - 0.5 * quad
    return out

def qda_predict(X, mus, covs, priors):
    return np.argmax(qda_scores(X, mus, covs, priors), axis=1)

def auc_pairwise(y, scores):
    y = np.asarray(y, dtype=int)
    scores = np.asarray(scores, dtype=float)
    pos = scores[y == 1]
    neg = scores[y == 0]
    wins = 0.0
    for sp in pos:
        for sn in neg:
            if sp > sn:
                wins += 1.0
    return wins / (len(pos) * len(neg))

def f1_score_binary(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    tp = np.sum((y_true == 1) & (y_pred == 1))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    return 0.5 * (precision + recall)
